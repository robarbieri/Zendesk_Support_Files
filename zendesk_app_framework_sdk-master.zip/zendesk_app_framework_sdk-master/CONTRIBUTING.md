# Contributing

Improvements are always welcome. Please follow these steps to contribute:

1. Submit a Pull Request with a detailed explanation of changes
2. Receive a :+1: from a core team member
3. Core team will merge your changes
