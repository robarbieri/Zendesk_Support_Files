'use strict';

import baseConfig from './base';

let config = {
  ENV: 'test'
};

export default Object.freeze(Object.assign(baseConfig, config));
