namespace ZendeskApi_v2.Models.Constants
{
    public static class TicketPriorities
    {
        public const string Urgent = "urgent";
        public const string High = "high";
        public const string Normal = "normal";
        public const string Low = "low";    
    }
}