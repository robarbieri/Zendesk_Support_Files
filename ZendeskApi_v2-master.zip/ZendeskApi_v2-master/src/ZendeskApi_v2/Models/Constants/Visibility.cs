﻿namespace ZendeskApi_v2.Models.Constants
{
	public static class Visibility
	{
		public const string Public = "public";
		public const string Restricted = "restricted";
		public const string Internet = "internal";
	}
}
