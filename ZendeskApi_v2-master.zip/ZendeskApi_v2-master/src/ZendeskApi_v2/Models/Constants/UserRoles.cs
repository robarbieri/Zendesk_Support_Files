namespace ZendeskApi_v2.Models.Constants
{
    public static class UserRoles
    {
        public const string EndUser = "end-user";
        public const string Agent = "agent";
        public const string Admin = "admin";        
    }
}