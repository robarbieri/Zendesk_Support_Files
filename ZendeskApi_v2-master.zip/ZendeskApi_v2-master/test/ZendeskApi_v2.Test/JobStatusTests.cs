using NUnit.Framework;

namespace Tests
{
    [TestFixture]
    public class JobStatusTests
    {
        //see TicketTests -> CanBulkUpdateTickets
    }
}