using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ZendeskApi.Client.Tests")]