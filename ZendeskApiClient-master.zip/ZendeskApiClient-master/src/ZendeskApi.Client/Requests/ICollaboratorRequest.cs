namespace ZendeskApi.Client.Requests
{
    public interface ICollaboratorRequest
    {
        
    }
}