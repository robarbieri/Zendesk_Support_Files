namespace ZendeskApi.Client.Models
{
    public enum ComponentStatus
    {
        Operational,
        Impeded,
        Inoperative,
        Monitoring,
        Identified
    }
}