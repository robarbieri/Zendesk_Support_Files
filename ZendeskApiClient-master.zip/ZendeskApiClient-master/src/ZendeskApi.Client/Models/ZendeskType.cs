﻿namespace ZendeskApi.Client.Models
{
    public enum ZendeskType
    {
        Ticket,
        Organization,
        User,
        Groups
    }
}
