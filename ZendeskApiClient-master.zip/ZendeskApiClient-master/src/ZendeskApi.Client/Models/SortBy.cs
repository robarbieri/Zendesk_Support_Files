namespace ZendeskApi.Client.Models
{
    public enum SortBy
    {
        Relevance,
        CreatedAt,
        UpdateAt,
        Priority,
        Status,
        TicketType,
        DeletedAt
    }
}
