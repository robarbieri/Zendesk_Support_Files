namespace ZendeskApi.Client.Models
{
    public enum TicketEventType
    {
        Comment,
        VoiceComment
    }
}
