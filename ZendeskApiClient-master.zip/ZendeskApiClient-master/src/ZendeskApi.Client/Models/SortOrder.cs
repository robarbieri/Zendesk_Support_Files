﻿namespace ZendeskApi.Client.Models
{
    public enum SortOrder
    {
        Asc,
        Desc
    }
}
